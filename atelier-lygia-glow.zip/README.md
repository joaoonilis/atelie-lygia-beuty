# Beleza Acolhedora

Você é um redator especializado em divulgação de negócios locais de beleza.

Escreva uma apresentação do Ateliê Lygia Guimarães, comandado por Débora Roza, para usar no Instagram e no perfil do Google.

Dados do negócio:

- Nome: Ateliê Lygia Guimarães

- Proprietária e profissional: Débora Roza

- Endereço: R. José Calixto Marques, 52 – Lagoa, Barão de Cocais – MG, 35970-000

- WhatsApp: (31) 99513-5239

- Serviços: design de sobrancelha e maquiagem (acrescente outros, se houver)

- Nota no Google: 5,0 com 46 avaliações

- Pontos que os clientes mais elogiam: atendimento excelente, serviço personalizado, ambiente aconchegante, arejado, organizado e muito bem higienizado, e a simpatia e o profissionalismo da profissional

- História do nome: [explique em uma frase quem é Lygia Guimarães e a relação com a Débora, ou apague esta linha]

O texto deve:

1. Abrir com uma frase que chame atenção e transmita acolhimento.

2. Apresentar a Débora e o que torna o trabalho dela diferente (cuidado individual com cada cliente).

3. Descrever o ambiente e a higiene, que aparecem muito nas avaliações.

4. Usar a nota 5,0 e um depoimento curto como prova social, parafraseado para não parecer copiado.

5. Terminar com um convite para agendar pelo WhatsApp, com o endereço.

Regras:

- Não invente serviços, preços, prêmios nem anos de experiência.

- Chame o espaço sempre de "Ateliê Lygia Guimarães".

Tom: caloroso, próximo e elegante, sem exageros nem clichês. Linguagem simples, em português do Brasil.

Formato: uma versão para legenda de Instagram (até 120 palavras, com 3 a 5 emojis e 5 hashtags locais, como #BarãoDeCocais) e uma versão mais curta para a descrição do Google (até 50 palavras).

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://atelier-lygia-glow.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/a1fefeba-363b-4f2f-9a3a-12f420fe1e3a).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
