import { createFileRoute } from "@tanstack/react-router";
import resultado1 from "@/assets/resultado-1.jpg.asset.json";
import resultado2 from "@/assets/resultado-2.jpg.asset.json";
import cliente1 from "@/assets/cliente-1.jpg.asset.json";
import cliente2 from "@/assets/cliente-2.jpg.asset.json";
import debora from "@/assets/debora.jpg.asset.json";

const WA = "https://wa.me/5531995135239?text=" + encodeURIComponent("Olá, Débora! Gostaria de agendar um horário no Ateliê Lygia Guimarães.");
const ADDRESS = "R. José Calixto Marques, 52 – Lagoa, Barão de Cocais – MG, 35970-000";
const MAPS = "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(ADDRESS);

const TITLE = "Ateliê Lygia Guimarães | Sobrancelhas e maquiagem em Barão de Cocais";
const DESC = "Design de sobrancelhas e maquiagem com Débora Roza, em Barão de Cocais – MG. Nota 5,0 no Google. Agende pelo WhatsApp.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: Index,
});

const btn =
  "inline-flex items-center justify-center rounded-full px-7 py-3.5 text-base font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background";
const btnPrimary = `${btn} bg-primary text-primary-foreground hover:opacity-90`;
const btnGhost = `${btn} border border-primary text-primary hover:bg-secondary`;

const brows = [
  { name: "Design personalizado", desc: "Avaliação do formato do rosto, da expressão e do seu estilo para sobrancelhas leves e harmoniosas.", price: "R$ 45" },
  { name: "Design com henna", desc: "Henna de alta qualidade para um preenchimento suave e duradouro.", price: "R$ 55" },
  { name: "Design com coloração", desc: "Para fios brancos ou muito claros, com acabamento uniforme e natural.", price: "R$ 55" },
  { name: "Design masculino", desc: "Sobrancelhas alinhadas, limpas e discretas, respeitando seu estilo.", price: "R$ 45" },
  { name: "Brow lamination", desc: "Alinha e organiza os fios para um efeito mais cheio e definido.", price: "R$ 150" },
  { name: "Epilação egípcia", desc: "Remoção dos pelos com linha, com precisão e delicadeza.", price: "A consultar" },
];

const reviews = [
  "Fiz design de sobrancelha, gostei demais. Atendimento excelente, lugar organizado, arejado e muito bem higienizado.",
  "Ambiente agradável, atendimento excelente!",
  "Além de ótima profissional, é também uma pessoa maravilhosa.",
];

function Section({ id, title, children }: { id: string; title: string; children: React.ReactNode }) {
  return (
    <section id={id} aria-labelledby={`${id}-t`} className="animate-fade-up mx-auto max-w-5xl px-6 py-20 sm:py-24">
      <div className="mx-auto max-w-3xl text-center">
        <span className="text-sm font-semibold uppercase tracking-[0.35em] text-accent">Ateliê Lygia</span>
        <h2 id={`${id}-t`} className="mt-3 font-display text-4xl font-semibold text-primary sm:text-5xl">{title}</h2>
      </div>
      <div className="mt-10">{children}</div>
    </section>
  );
}

function Index() {
  return (
    <main className="bg-background text-foreground motion-safe:scroll-smooth">
      <section aria-label="Destaque do Ateliê Lygia Guimarães" className="mx-auto max-w-6xl px-6 pt-6 sm:pt-8">
        <figure className="animate-fade-up mx-auto max-w-2xl overflow-hidden rounded-[2rem] border border-border/70 bg-card/70 p-3 shadow-xl">
          <img
            src="/uploads/debora.mroza_1780703126_3913141160477277241_5414351860.jpg"
            alt="Destaque do Ateliê Lygia Guimarães"
            className="mx-auto max-h-[420px] w-auto max-w-full object-contain"
          />
        </figure>
      </section>

      {/* Início */}
      <header className="relative mx-auto flex min-h-dvh max-w-6xl flex-col items-center justify-center overflow-hidden px-6 py-16 text-center">
        <div className="absolute inset-x-6 top-10 -z-0 h-72 rounded-full bg-secondary/70 blur-3xl sm:inset-x-20" />
        <div className="relative z-10 max-w-3xl">
        <svg viewBox="0 0 300 80" className="mx-auto w-56 sm:w-72" aria-hidden="true">
          <path className="brow-path" d="M10 62 C 70 18, 170 6, 290 40" fill="none" stroke="var(--accent)" strokeWidth="5" strokeLinecap="round" />
        </svg>
        <p className="mt-6 text-sm font-medium uppercase tracking-[0.25em] text-muted-foreground">Barão de Cocais · MG</p>
        <h1 className="mt-3 font-display text-5xl font-semibold leading-tight sm:text-7xl">Ateliê Lygia Guimarães</h1>
        <p className="mx-auto mt-5 max-w-md text-lg text-muted-foreground">
          Design de sobrancelhas e maquiagem com Débora Roza, pensados para o seu rosto e o seu jeito.
        </p>
        <div className="mt-9"><a href={WA} target="_blank" rel="noopener noreferrer" className={btnPrimary}>Agendar pelo WhatsApp</a></div>
        <div className="mt-10 grid gap-3 text-sm text-muted-foreground sm:grid-cols-3">
          <span className="rounded-full border border-border/70 bg-card/70 px-4 py-2 shadow-sm">Nota 5,0 no Google</span>
          <span className="rounded-full border border-border/70 bg-card/70 px-4 py-2 shadow-sm">Atendimento personalizado</span>
          <span className="rounded-full border border-border/70 bg-card/70 px-4 py-2 shadow-sm">Barão de Cocais</span>
        </div>
        </div>
      </header>

      {/* Serviços */}
      <Section id="servicos" title="Serviços">
        <div className="grid gap-6">
          <article className="rounded-3xl border border-border/70 bg-card/80 p-7 shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-xl">
            <h3 className="font-display text-3xl font-semibold">Design de sobrancelha</h3>
            <p className="mt-2 text-muted-foreground">Cada design começa por uma avaliação do seu rosto — nada de molde pronto.</p>
            <ul className="mt-6 divide-y divide-border">
              {brows.map((s) => (
                <li key={s.name} className="grid grid-cols-[minmax(0,1fr)_auto] gap-4 py-4">
                  <div className="min-w-0">
                    <p className="font-semibold">{s.name}</p>
                    <p className="text-sm text-muted-foreground">{s.desc}</p>
                  </div>
                  <p className="shrink-0 font-display text-xl font-semibold text-primary">{s.price}</p>
                </li>
              ))}
            </ul>
          </article>
          <div className="grid gap-6 sm:grid-cols-2">
            <article className="rounded-3xl border border-border/70 bg-card/80 p-7 shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-xl">
              <h3 className="font-display text-3xl font-semibold">Maquiagem</h3>
              <p className="mt-2 text-muted-foreground">Uma maquiagem que valoriza sua beleza natural, para o dia a dia ou para uma ocasião especial.</p>
              <p className="mt-4 text-sm font-semibold text-primary">Valor a combinar pelo WhatsApp</p>
            </article>
            <article className="rounded-3xl border border-border/70 bg-card/80 p-7 shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-xl">
              <h3 className="font-display text-3xl font-semibold">Hidralips</h3>
              <p className="mt-2 text-muted-foreground">Hidrata e realça os lábios, devolvendo maciez, viço e cor.</p>
              <p className="mt-4 font-display text-xl font-semibold text-primary">R$ 150</p>
            </article>
          </div>
          <p className="text-sm text-muted-foreground">Formas de pagamento: Pix, dinheiro e cartão (débito e crédito).</p>
        </div>
      </Section>

      {/* Quem cuida */}
      <Section id="sobre" title="Quem cuida de você">
        <div className="grid items-center gap-8 lg:grid-cols-[0.95fr_1.05fr]">
          <div className="space-y-5 rounded-3xl border border-border/70 bg-card/70 p-7 text-lg leading-relaxed shadow-sm">
            <p>Prazer, sou a <strong>Débora Roza</strong>. Sou especialista em sobrancelhas e atuo na área há 4 anos, com técnica, precisão e cuidado.</p>
            <p className="text-muted-foreground">No Ateliê Lygia Guimarães, o atendimento é sem pressa: conversamos, avaliamos juntas e só então começamos. O espaço é aconchegante, arejado, organizado e higienizado com atenção a cada detalhe — para você se sentir à vontade do início ao fim.</p>
          </div>
          <figure className="overflow-hidden rounded-3xl shadow-xl">
            <img src={debora.url} alt="Débora Roza, especialista em sobrancelhas do Ateliê Lygia Guimarães" className="aspect-[4/5] w-full object-cover" loading="lazy" />
          </figure>
        </div>
      </Section>

      {/* Trabalhos */}
      <Section id="trabalhos" title="Trabalhos">
        <div className="grid grid-cols-2 gap-4 sm:gap-6 lg:grid-cols-4">
          {[
            { src: resultado1.url, alt: "Resultado de design de sobrancelhas com fios alinhados" },
            { src: resultado2.url, alt: "Resultado de brow lamination, sobrancelhas cheias e definidas" },
            { src: cliente1.url, alt: "Cliente do Ateliê Lygia Guimarães com sobrancelhas naturais" },
            { src: cliente2.url, alt: "Cliente do Ateliê Lygia Guimarães sorrindo após o atendimento" },
          ].map((img) => (
            <figure key={img.src} className="overflow-hidden rounded-3xl">
              <img src={img.src} alt={img.alt} className="aspect-[4/5] w-full object-cover transition-transform duration-500 hover:scale-105" loading="lazy" />
            </figure>
          ))}
        </div>
        <p className="mt-6 text-sm text-muted-foreground">
          Mais resultados no Instagram: <a href="https://instagram.com/debora.mroza" target="_blank" rel="noopener noreferrer" className="font-semibold text-primary underline underline-offset-4">@debora.mroza</a>
        </p>
      </Section>

      {/* Avaliações */}
      <Section id="avaliacoes" title="Avaliações">
        <p className="flex flex-wrap items-baseline justify-center gap-3 rounded-3xl border border-border/70 bg-card/70 p-7 shadow-sm">
          <span className="font-display text-6xl font-semibold text-primary">5,0</span>
          <span className="text-accent" aria-hidden="true">★★★★★</span>
          <span className="text-muted-foreground">em 46 avaliações no Google</span>
        </p>
        <ul className="mt-8 space-y-5">
          {reviews.map((r) => (
            <li key={r}>
              <blockquote className="border-l-2 border-accent pl-5 font-display text-2xl italic leading-snug">“{r}”</blockquote>
            </li>
          ))}
        </ul>
      </Section>

      {/* Contato */}
      <Section id="contato" title="Contato">
        <address className="space-y-2 text-lg not-italic">
          <p>{ADDRESS}</p>
          <p>WhatsApp: <a href={WA} className="underline underline-offset-4 focus-visible:outline-2 focus-visible:outline-ring">(31) 99513-5239</a></p>
          <p>Instagram: <a href="https://instagram.com/debora.mroza" target="_blank" rel="noopener noreferrer" className="underline underline-offset-4">@debora.mroza</a></p>
        </address>
        <div className="mt-8 flex flex-col gap-3 sm:flex-row">
          <a href={WA} target="_blank" rel="noopener noreferrer" className={btnPrimary}>Agendar pelo WhatsApp</a>
          <a href={MAPS} target="_blank" rel="noopener noreferrer" className={btnGhost}>Abrir no Google Maps</a>
        </div>
      </Section>

      <footer className="px-6 py-10 text-center text-sm text-muted-foreground">Ateliê Lygia Guimarães · Débora Roza</footer>
    </main>
  );
}
